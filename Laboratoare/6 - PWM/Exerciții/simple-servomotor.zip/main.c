#include "ClockSettings.h"
#include "Pwm.h"

int main() {
	
	SystemClock_Configure();
	SystemClockTick_Configure();
	TPM2_Init();
	
	for(;;){
		if(flag_1s){
			Signal_Control();
			flag_1s = 0U;
		}
	}
}
