#include "Adc.h"
#include "ClockSettings.h"
#include "Pwm.h"

#define ANGLE_INCREMENT 37

int main() {
	
	SystemClock_Configure();
	SystemClockTick_Configure();
	ADC0_Init();
	TPM2_Init();
	
	for(;;) {
		if(flag_150ms){
			uint16_t analog_input = (uint16_t) ADC0_Read();
			TPM2->CNT = 0x0000; 
			TPM2->MOD = 375 * 20;

			TPM2->CONTROLS[0].CnV = ANGLE_INCREMENT * 5 + (analog_input * 2 * 375)/0xFFFF;
			flag_150ms = 0U;
		}
	}
}