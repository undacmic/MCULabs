#include "Pwm.h"
#include "ClockSettings.h"


int main() {
	
	SystemClock_Configure();
	SystemClockTick_Configure();
	TPM2_Init();
	
	for(;;) {
		if(flag_500ms){
			Brightness_Control();
			flag_500ms = 0U;
		}
	}
	
}