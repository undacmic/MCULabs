#include "ClockSettings.h"
#include "Pwm.h"

int main() {
	
	SystemClock_Configure();
	SystemClockTick_Configure();
	TPM2_Init();
	
	for(;;){
		if(flag_5s){
			Signal_Control();
			flag_5s = 0U;		
		}
	}
}
