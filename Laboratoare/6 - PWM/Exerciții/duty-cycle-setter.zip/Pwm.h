#include "MKL25Z4.h"

void TPM2_Init(void);
void Signal_Control(void);