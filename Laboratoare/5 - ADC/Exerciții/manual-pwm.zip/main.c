#include "Uart.h"
#include "Adc.h"
#include "ClockSettings.h"
#include "Pwm.h"

extern uint8_t buffer_value[6]; // 0 - 65535 (avand in vedere rezolutia pe 16 biti a perifericului ADC configurat)

int main() {
	
	SystemClock_Configure();
	SystemClockTick_Configure();
	UART0_Init(115200);
	ADC0_Init();
	TPM2_Init();
	
	for(;;) {
		if(flag_100ms){
			uint16_t analog_input = (uint16_t) ADC0_Read();
			uint16_t duty_cycle = (analog_input * 100) / 0xFFFF;
			TPM2->CNT = 0x0000;
			TPM2->MOD = 375 * 10;
			TPM2->CONTROLS[0].CnV = (375 * 10 * duty_cycle) / 100;
			flag_100ms = 0U;
		}
	}
}