#include "Adc.h"
#include "Uart.h"

#define ROTATION_SENSOR (14)
#define LIGHT_SENSOR (11)

int main() {
	
	UART0_Init(115200);
	ADC0_Init();
	
	for(;;) {
		uint16_t data = ADC0_Read(ROTATION_SENSOR);
		data = ADC0_Read(LIGHT_SENSOR);
	}
	
}
