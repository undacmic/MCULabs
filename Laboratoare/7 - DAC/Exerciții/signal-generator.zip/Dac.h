#include "MKL25Z4.h"

void DAC0_Init(void);
int Sine_Output(int *val);
int Triangle_Output(int *val);
int Square_Output(int *val);
int Sawtooth_Output(int *val);
