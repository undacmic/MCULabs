#include "MKL25Z4.h"

void Switch_Init(void);
void PORTA_IRQHandler(void);
