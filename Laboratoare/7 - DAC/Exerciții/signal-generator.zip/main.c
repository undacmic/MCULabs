#include "Dac.h"
#include "Gpio.h"
#include "ClockSettings.h"

extern uint8_t signal_type;

int main() {
	
	SystemClock_Configure();
	SystemClockTick_Configure();
	Switch_Init();
	DAC0_Init();
	
	int step = 0;
	int sampledValue = 0;
	
	for(;;){
		switch(signal_type){
			case 0: 
				sampledValue = Triangle_Output(&step); 
				break;
			case 1: 
				sampledValue = Square_Output(&step);
				break;
			case 2: 
				sampledValue = Sine_Output(&step);
				break;
			default: 
				sampledValue = Sawtooth_Output(&step);
		}
		DAC0->DAT[0].DATL = DAC_DATL_DATA0(sampledValue);
		DAC0->DAT[0].DATH = DAC_DATH_DATA1(sampledValue>>8);
	}
}