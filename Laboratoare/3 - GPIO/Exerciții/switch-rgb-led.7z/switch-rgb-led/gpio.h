#include "MKL25Z4.h"
void Switch_Init(void);
void RGBLed_Init(void);
void PORTA_IRQHandler(void);