#include "gpio.h"

int main()
{
	Switch_Init();
	RGBLed_Init();
	for(;;) {}
}

