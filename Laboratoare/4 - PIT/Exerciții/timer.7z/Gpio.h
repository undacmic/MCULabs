#include "MKL25Z4.h"

void OutputPIN_Init(void);